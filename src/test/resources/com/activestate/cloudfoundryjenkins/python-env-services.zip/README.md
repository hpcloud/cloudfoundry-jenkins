# A simple Python app

## Local development

    pip install -r requirements.txt
    python app.py

## Deploying to Stackato

    stackato push -n
