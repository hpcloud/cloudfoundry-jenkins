import os
import sys
from bottle import route, run, template

print("Running using: %s" % sys.executable)

html_template = r'''
  % for name, value in envlist.items():
    {{name}}: {{value}}
  % end
'''

@route('/')
def index():
    return template(html_template, envlist=os.environ)

run(host='0.0.0.0', port=int(os.getenv("PORT", 8080)))
